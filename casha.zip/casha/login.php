<?php
session_start();
$hal = "Login Admin CaSha";
$success = false;
$error = false;

?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="keywords" content="wrappixel, admin dashboard, html css dashboard, web dashboard, bootstrap 5 admin, bootstrap 5, css3 dashboard, bootstrap 5 dashboard, Ample lite admin bootstrap 5 dashboard, frontend, responsive bootstrap 5 admin template, Ample admin lite dashboard bootstrap 5 dashboard template" />
  <meta name="description" content="Ample Admin Lite is powerful and clean admin dashboard template, inpired from Bootstrap Framework" />
  <meta name="robots" content="noindex,nofollow" />
  <title>Login CaSha</title>
  <link rel="canonical" href="https://www.wrappixel.com/templates/ample-admin-lite/" />
  <!-- Favicon icon -->
  <link rel="icon" type="image/png" sizes="16x16" href="plugins/images/favicon.png" />
  <script src="/casha/admin/js/sa.js"></script>


  <!-- Custom CSS -->
  <link href="admin/css/style.min.css" rel="stylesheet" />
  <script src="/casha/admin/js/sa.js"></script>
</head>

<body>

  <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full" data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">

    <div class="row mt-5 justify-content-center">
      <div class="col-md-4 mt-5">

        <?php
        if (isset($_POST['login'])) {
          require 'comp/koneksi.php';
          $username = clear($_POST['username']);
          $password = clear($_POST['password']);

          $cek = query_select('users', "username = '$username' AND password = '$password'");

          if ($cek) {
            if ($cek[0]['role'] == 1) {
              $_SESSION['admin'] =  true;
            }
            $_SESSION['login'] =  true;
            $success = true;
          } else {
            $error = true;
          }
        }
        ?>

        <div class="card shadow">
          <div class="card-body">
            <h3>Login CaSha</h3>
            <form action="" method="post" enctype="multipart/form-data">
              <div class="mb-3">
                <label for="judul" class="form-label">Username</label>
                <input type="text" class="form-control" id="judul" name="username" placeholder="">
              </div>
              <div class="mb-3">
                <label for="judul" class="form-label">Password</label>
                <input type="password" class="form-control" id="judul" name="password" placeholder="">
              </div>
              <button class="btn btn-primary" name="login">Login</button>
            </form>
          </div>
        </div>
      </div>
    </div>

  </div>

  <?php
  if ($success) {
    sAlert('Berhasil', 'Login Berhasil', 'success');

    if (isset($_SESSION['admin'])) {
      direct('admin/index.php', 1500);
    } else {
      direct('index.php', 1500);
    }
  }
  if ($error) {
    sAlert('Gagal', 'Username / password salah', 'error');
  }
  ?>

  <?php require 'comp/footer.php'; ?>