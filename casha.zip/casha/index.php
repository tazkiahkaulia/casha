<?php $halaman = "Home | CaSha" ?>
<?php require 'Comp/header.php'; ?>
<?php

require 'comp/koneksi.php';

$berita = query_select('berita');
krsort($berita);
?>



<style>
  .shadow-sm {
    box-shadow: 0px 3px 5px rgba(0, 0, 0, .15);
  }

  footer {
    text-align: center;
  }

  @media (max-width: 576px) {
    .card-title {
      font-size: 14px;
    }

    .card-text {
      font-size: 12px;
    }

    footer p {
      font-size: 10px;
    }
  }
</style>
<!-- Navbar -->
<?php require 'Comp/navbar.php'; ?>

<?php
function cetakIsi($kata)
{
  $data = '';
  for ($i = 0; $i < 100; $i++) {
    $data .= $kata[$i];
  }

  return $data;
}
?>
<!-- endnavbar -->

<!-- Jumbotron -->
<?php require 'Comp/jumbotron.php' ?>
<!-- End Jumbotron -->

<!-- content -->
<section class="main mt-4 pt-4" id="berita " style="min-height: 88vh;">
  <div class="container">

    <div class="text-center">
      <h3 class="mb-5 pb-3">Kabar Berita Terbaru</h3>
    </div>

    <div class="row">

      <?php if ($berita) : ?>

        <?php $i = 0 ?>
        <?php foreach ($berita as $item) : ?>
          <?php
          if ($i > 2) {
            break;
          }
          ?>
          <div class="col-md-4 col-6 mb-4" data-aos="fade-up" data-aos-duration="1200">
            <div class="card shadow border-0">
              <img class="card-img-top" src="assets/img/<?= $item['img'] ?>" alt="Card image cap">
              <div class="card-body">
                <h6 class="card-title fw-bold"><?= $item['judul'] ?></h6>
                <p class="text-secondary"><?= cetakIsi($item['isi']) ?>...</p>
                <a href="detail.php?id=<?= $item['id'] ?>">Selengkapnya</a>
              </div>
            </div>
          </div>
          <?php $i++ ?>
        <?php endforeach; ?>
      <?php endif; ?>

      <div class="col-12 text-center mt-5">
        <a href="berita.php" style="text-decoration: none;" class="text-info">Lihat Semua Kabar Berita</a>
      </div>

    </div>

    <div class="text-center mt-5">
      <h3 class="mb-4 pb-3">Galery</h3>
    </div>

    <div class="row mt-5 mb-5">
      <div class="col-md-4 p-4" data-aos="fade-right" data-aos-duration="1200">
        <div class="card shadow-sm border-0">
          <div class="card-body text-center">
            <img src="assets/img/1.jpg" alt="" class="img-fluid rounded">
          </div>
        </div>
      </div>
      <div class="col-md-4 p-4" data-aos="fade-up" data-aos-duration="1200">
        <div class="card shadow-sm border-0">
          <div class="card-body text-center">
            <img src="assets/img/2.jpg" alt="" class="img-fluid rounded">
          </div>
        </div>
      </div>
      <div class="col-md-4 p-4" data-aos="fade-left" data-aos-duration="1200">
        <div class="card shadow-sm border-0">
          <div class="card-body text-center">
            <img src="assets/img/3.jpg" alt="" class="img-fluid rounded">
          </div>
        </div>
      </div>
    </div>

    <div class="text-center">
      <h3 class="mb-4 pb-3">Data Penyetoran</h3>
    </div>
    <?php
    $penyetoran = query_select('penyetoran');
    $stok = query_select('stok_penyetoran');
    krsort($penyetoran);

    foreach ($stok as $val) :
    ?>
      <h5><?= $val['jenis_ikan'] ?> : <?= $val['stok_masuk'] ?> kg <?= $val['stok_masuk'] * 100 / $val['stok_maksimal'] > 50 ? "<span class='badge bg-warning'>Maksimal " . $val['stok_maksimal'] . " kg</span>" : "" ?></h5>
    <?php endforeach; ?>
    <br>
    <table class="table">
      <thead>
        <tr>
          <th>No</th>
          <th>Nama Kapal</th>
          <th>Alat Tangap</th>
          <th>Waktu Tangkapan</th>
          <th>Ikan</th>
          <th>Jenis Ikan</th>
          <th>Jumlah Ikan (Kg)</th>
        </tr>
      </thead>
      <tbody>
        <?php $i = 1 ?>
        <?php foreach ($penyetoran as $item) : ?>
          <?php if ($i > 5) : ?>
            <?php
            break;
            ?>
          <?php endif; ?>
          <tr>
            <td>
              <?= $i ?>
            </td>
            <td><?= $item['kapal'] ?></td>
            <td><?= $item['alat'] ?></td>
            <td><?= $item['waktu'] ?></td>
            <td><?= $item['ikan'] ?></td>
            <td><?= $item['jenis_ikan'] ?></td>
            <td><?= $item['stok'] ?></td>

          </tr>
          <?php $i++ ?>
        <?php endforeach; ?>
      </tbody>
    </table>
    <div class=" text-center mt-5">
      <a href="penyetoran.php" style="text-decoration: none;" class="text-info">Lihat Semua Data Penyetoran</a>
    </div>
  </div>

</section>
<!-- endContent -->
<script>
  AOS.init();
</script>

<footer class="pt-3 pb-4 bg-light mt-5">
  <p class="mb-0 text-secondary">Copyright 2022 | CaSha Web</p>
</footer>

<?php include 'Comp/footer.php'; ?>