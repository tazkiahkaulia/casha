<?php
require 'comp/header.php';

if (isset($_GET['id'])) {
  $id = clear($_GET['id']);

  query_delete('users', "id = '$id'");
}

sAlert('Berhasil', 'Nelayan Berhasil Dihapus', 'success');
direct('nelayan.php', 1000);
