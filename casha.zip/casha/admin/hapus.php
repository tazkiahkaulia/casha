<?php
require 'comp/header.php';

if (isset($_GET['soal'])) {
  $id_soal = $_GET['soal'];
  $soal = query_select('soal', "id_soal='$id_soal'");
  if ($soal) {
    $pertanyaan = query_select('pertanyaan', "id_soal='$id_soal'");

    if ($pertanyaan) {
      foreach ($pertanyaan as $key => $value) {
        delFile('../files/' . $value['pertanyaan']);
        delFile('../files/' . $value['A']);
        delFile('../files/' . $value['B']);
        delFile('../files/' . $value['C']);
        delFile('../files/' . $value['D']);
        delFile('../files/' . $value['pembahasan']);
      }

      query_delete('pertanyaan', "id_soal='$id_soal'");
    }
    query_delete('soal', "id_soal='$id_soal'");

    sAlert('Berhasil', 'Soal Berhasil Dihapus', 'success');
  }

  direct("kelas-$_GET[kelas].php");
} else if (isset($_GET['pertanyaan'])) {
  $id_pertanyaan = $_GET['pertanyaan'];
  $id_soal = $_GET['soal'];
  $pertanyaan = query_select('pertanyaan', "id_pertanyaan='$id_pertanyaan'");
  if ($pertanyaan) {
    delFile('../files/' . $pertanyaan[0]['pertanyaan']);
    delFile('../files/' . $pertanyaan[0]['A']);
    delFile('../files/' . $pertanyaan[0]['B']);
    delFile('../files/' . $pertanyaan[0]['C']);
    delFile('../files/' . $pertanyaan[0]['D']);
    delFile('../files/' . $pertanyaan[0]['pembahasan']);

    query_delete('pertanyaan', "id_pertanyaan='$id_pertanyaan'");
    sAlert('Berhasil', 'Pertanyaan Berhasil Dihapus', 'success');
  }
  direct('detail-soal.php?soal=' . $id_soal);
}
