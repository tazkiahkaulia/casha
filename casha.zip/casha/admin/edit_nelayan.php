<?php
$hal = "Edit Nelayan";
$success = false;
if (!isset($_GET['id'])) {
  header("location: nelayan.php");
}


?>
<?php require 'comp/header.php'; ?>

<div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full" data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">

  <?php require 'comp/navbar.php'; ?>
  <?php require 'comp/aside.php'; ?>

  <div class="page-wrapper">
    <?php require 'comp/sidebar-toggle.php'; ?>

    <div class="container-fluid">
      <!-- Content -->
      <h3 class="mb-4">Edit Nelayan</h3>

      <?php
      $id = clear($_GET['id']);
      $nelayan = query_select('users', "id = '$id'");
      if (!$nelayan) {
        direct('nelayan.php');
        die;
      }
      $nelayan = $nelayan[0];
      ?>

      <?php
      if (isset($_POST['ubah'])) {
        $data = [
          'id' => '',
          "username" => clear($_POST['username']),
          "password" => clear($_POST['password']),
          "nama" => clear($_POST['nama']),
          "alamat" => clear($_POST['alamat']),
          "role" => 2,
        ];

        $sql = "UPDATE users SET username = '$data[username]', password = '$data[password]', nama = '$data[nama]', alamat = '$data[alamat]' WHERE id = '$id'";
        $success = true;
        $conn->query($sql);
        // query_insert('users', $data);
      }
      ?>


      <div class="row">
        <div class="col-sm-12">
          <div class="white-box">
            <a href="nelayan.php" class="btn btn-secondary btn-sm text-white mb-3" value="ubah"><i class="fas fa-arrow-left"></i> Kembali</a>

            <form action="" method="post" enctype="multipart/form-data">
              <div class="mb-3">
                <label for="judul" class="form-label">Username</label>
                <input type="text" class="form-control" id="judul" name="username" placeholder="" value="<?= $nelayan['username'] ?>">
              </div>
              <div class="mb-3">
                <label for="judul" class="form-label">Passord</label>
                <input type="password" class="form-control" id="judul" name="password" placeholder="" value="<?= $nelayan['password'] ?>">
              </div>
              <div class=" mb-3">
                <label for="judul" class="form-label">Nama</label>
                <input type="text" class="form-control" id="judul" name="nama" placeholder="" value="<?= $nelayan['nama'] ?>">
              </div>
              <div class=" mb-3">
                <label for="judul" class="form-label">Alamat</label>
                <textarea name="alamat" id="" cols="30" class="form-control" rows="10"><?= $nelayan['alamat'] ?></textarea>
              </div>

              <button type="submit" class="btn btn-info btn-sm text-white" name="ubah">Simpan</button>
            </form>


          </div>
        </div>
      </div>

      <!-- End Content -->
    </div>
  </div>

</div>

<?php
if ($success) {
  sAlert('Berhasil', 'Nelayan Berhasil Diedit', 'success');
  direct("nelayan.php", 1000);
}
?>

<?php require 'comp/footer.php'; ?>