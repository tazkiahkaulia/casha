<?php
$hal = "Dashboard Admin CaSha";
?>
<?php require 'comp/header.php'; ?>

<div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full" data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">

  <?php require 'comp/navbar.php'; ?>
  <?php require 'comp/aside.php'; ?>

  <div class="page-wrapper">
    <?php require 'comp/sidebar-toggle.php'; ?>

    <div class="container-fluid">
      <!-- Content -->
      <h3 class="mb-4">Selamat Datang, Admin!</h3>

      <!-- End Content -->
    </div>
  </div>

</div>

<?php require 'comp/footer.php'; ?>