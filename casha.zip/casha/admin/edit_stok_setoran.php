<?php
$hal = "Edit Stok Setoran";
$success = false;

if (!isset($_GET['id'])) {
  header('setoran.php');
  die;
}



?>
<?php require 'comp/header.php'; ?>

<div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full" data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">

  <?php require 'comp/navbar.php'; ?>
  <?php require 'comp/aside.php'; ?>

  <div class="page-wrapper">
    <?php require 'comp/sidebar-toggle.php'; ?>

    <div class="container-fluid">
      <!-- Content -->
      <h3 class="mb-4">Edit Stok Setoran</h3>

      <?php
      $id = clear($_GET['id']);

      $penyetoran = query_select('stok_penyetoran', "id = '$id'");

      if (!$penyetoran) {
        direct('setoran.php');
        die;
      }

      $penyetoran = $penyetoran[0];

      if (isset($_POST['ubah'])) {
        $data = [
          'id' => '',
          "stok_maksimal" => clear($_POST['stok_maksimal']),
        ];

        $success = true;
        $sql = "UPDATE stok_penyetoran SET stok_maksimal = '$data[stok_maksimal]' WHERE id = '$id'";
        $conn->query($sql);
      }
      ?>


      <div class="row">
        <div class="col-sm-12">
          <div class="white-box">
            <a href="stok-setoran.php" class="btn btn-secondary btn-sm text-white mb-3" value="ubah"><i class="fas fa-arrow-left"></i> Kembali</a>

            <form action="" method="post" enctype="multipart/form-data">
              <div class="mb-3">
                <label for="judul" class="form-label">Jenis Ikan</label>
                <input type="text" class="form-control" id="judul" name="kapal" placeholder="" value="<?= $penyetoran['jenis_ikan'] ?>" disabled>
              </div>
              <div class="mb-3">
                <label for="judul" class="form-label">Stok Maksimal</label>
                <input type="number" class="form-control" id="judul" name="stok_maksimal" placeholder="" value="<?= $penyetoran['stok_maksimal'] ?>">
              </div>
              <button type="submit" class="btn btn-info btn-sm text-white" name="ubah">Simpan</button>
            </form>


          </div>
        </div>
      </div>

      <!-- End Content -->
    </div>
  </div>

</div>

<?php
if ($success) {
  sAlert('Berhasil', 'Stok Maksimal Ikan Berhasil Diubah', 'success');
  direct("stok-setoran.php", 1000);
}
?>

<?php require 'comp/footer.php'; ?>