<?php
$hal = "Edit Kabar Berita";
$success = false;

if (!isset($_GET['id'])) {
  header("location: index.php");
}



?>
<?php require 'comp/header.php'; ?>

<div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full" data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">

  <?php require 'comp/navbar.php'; ?>
  <?php require 'comp/aside.php'; ?>

  <div class="page-wrapper">
    <?php require 'comp/sidebar-toggle.php'; ?>

    <div class="container-fluid">
      <!-- Content -->

      <?php
      $id = clear($_GET['id']);
      if (isset($_POST['ubah'])) {
        $data = [
          'id' => $id,
          "judul" => clear($_POST['judul']),
          "isi" => clear($_POST['isi']),
        ];

        $sql = "UPDATE berita SET judul = '$data[judul]', isi = '$data[isi]' WHERE id = '$id'";

        $conn->query($sql);
        $success = true;
      }
      ?>

      <?php
      $berita = query_select("berita", "id='$id'");
      if (!$berita) {
        direct('kabar_berita.php');
        die;
      }
      $berita = $berita[0];
      ?>
      <h3 class="mb-4">Edit Kabar Berita</h3>


      <div class="row">
        <div class="col-sm-12">
          <div class="white-box">
            <a href="kabar_berita.php" class="btn btn-secondary btn-sm text-white mb-3" value="ubah"><i class="fas fa-arrow-left"></i> Kembali</a>

            <form action="" method="post">
              <div class="mb-3">
                <label for="judul" class="form-label">Judul Berita</label>
                <input type="text" class="form-control" id="judul" name="judul" value="<?= $berita['judul'] ?>" placeholder="">
              </div>
              <div class="mb-3">
                <label for="isi" class="form-label">Isi Berita</label>
                <textarea class="form-control" id="isi" name="isi" rows="3" value=""><?= $berita['isi'] ?></textarea>
              </div>
              <button type="submit" class="btn btn-info btn-sm text-white" name="ubah">Simpan</button>
            </form>


          </div>
        </div>
      </div>

      <!-- End Content -->
    </div>
  </div>

</div>

<?php
if ($success) {
  sAlert('Berhasil', 'Kabar Berita Berhasil Diubah', 'success');
  direct("kabar_berita.php", 1000);
}
?>

<?php require 'comp/footer.php'; ?>