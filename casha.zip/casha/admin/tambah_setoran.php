<?php
$hal = "Tambah Setoran";
$success = false;
$error = false;

?>
<?php require 'comp/header.php'; ?>

<div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full" data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">

  <?php require 'comp/navbar.php'; ?>
  <?php require 'comp/aside.php'; ?>

  <div class="page-wrapper">
    <?php require 'comp/sidebar-toggle.php'; ?>

    <div class="container-fluid">
      <!-- Content -->
      <h3 class="mb-4">Tambah Setoran</h3>

      <?php
      if (isset($_POST['add'])) {
        $data = [
          'id' => '',
          "kapal" => clear($_POST['kapal']),
          "alat" => clear($_POST['alat']),
          "waktu" => clear($_POST['waktu']),
          "jenis_ikan" => clear($_POST['jenis_ikan']),
          "ikan" => clear($_POST['ikan']),
          "stok" => clear($_POST['stok']),
        ];

        $getDataStok = query_select('stok_penyetoran', "jenis_ikan = '$data[jenis_ikan]'");

        if (($getDataStok[0]['stok_maksimal'] - $getDataStok[0]['stok_masuk']) > $data['stok']) {
          query_insert('penyetoran', $data);
          $success = true;
          $stokBaru = $getDataStok[0]['stok_masuk'] + $data['stok'];
          $updateStokPenyetoran = "UPDATE stok_penyetoran SET stok_masuk = '$stokBaru' WHERE jenis_ikan = '$data[jenis_ikan]'";
          $conn->query($updateStokPenyetoran);
        } else {
          $error = true;
        }
      }
      ?>


      <div class="row">
        <div class="col-sm-12">
          <div class="white-box">
            <a href="setoran.php" class="btn btn-secondary btn-sm text-white mb-3" value="ubah"><i class="fas fa-arrow-left"></i> Kembali</a>

            <form action="" method="post" enctype="multipart/form-data">
              <div class="mb-3">
                <label for="judul" class="form-label">Nama Kapal</label>
                <input type="text" class="form-control" id="judul" name="kapal" placeholder="">
              </div>
              <div class="mb-3">
                <label for="judul" class="form-label">Alat Tangkap</label>
                <input type="text" class="form-control" id="judul" name="alat" placeholder="">
              </div>
              <div class="mb-3">
                <label for="judul" class="form-label">Waktu Penangkapan</label>
                <input type="date" class="form-control" id="judul" name="waktu" placeholder="">
              </div>
              <div class="mb-3">
                <label for="judul" class="form-label">Ikan</label>
                <input type="text" class="form-control" id="judul" name="ikan" placeholder="">
              </div>
              <div class="mb-3">
                <label for="judul" class="form-label">Jenis Ikan</label>
                <select name="jenis_ikan" id="" class="form-control">
                  <option value="Pelagis">Pelagis</option>
                  <option value="Demersal">Demersal</option>
                </select>
              </div>
              <div class="mb-3">
                <label for="judul" class="form-label">Stok Masuk</label>
                <input type="number" class="form-control" id="judul" name="stok" placeholder="">
              </div>

              <button type="submit" class="btn btn-info btn-sm text-white" name="add">Simpan</button>
            </form>


          </div>
        </div>
      </div>

      <!-- End Content -->
    </div>
  </div>

</div>

<?php
if ($success) {
  sAlert('Berhasil', 'Setoran Berhasil Ditambah', 'success');
  direct("setoran.php", 1000);
}
if ($error) {
  sAlert('Gagal', 'Stok Setoran Melebihi Stok Maksimal', 'error');
}
?>

<?php require 'comp/footer.php'; ?>