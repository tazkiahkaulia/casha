<?php
$hal = "Edit Setoran";
$success = false;
$error = false;

if (!isset($_GET['id'])) {
  header('setoran.php');
  die;
}



?>
<?php require 'comp/header.php'; ?>

<div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full" data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">

  <?php require 'comp/navbar.php'; ?>
  <?php require 'comp/aside.php'; ?>

  <div class="page-wrapper">
    <?php require 'comp/sidebar-toggle.php'; ?>

    <div class="container-fluid">
      <!-- Content -->
      <h3 class="mb-4">Edit Setoran</h3>

      <?php
      $id = clear($_GET['id']);

      $penyetoran = query_select('penyetoran', "id = '$id'");

      if (!$penyetoran) {
        direct('setoran.php');
        die;
      }

      $penyetoran = $penyetoran[0];

      if (isset($_POST['ubah'])) {
        $data = [
          'id' => '',
          "kapal" => clear($_POST['kapal']),
          "alat" => clear($_POST['alat']),
          "waktu" => clear($_POST['waktu']),
          "jenis_ikan" => clear($_POST['jenis_ikan']),
          "ikan" => clear($_POST['ikan']),
          "stok" => clear($_POST['stok']),
        ];

        $getData = query_select('stok_penyetoran', "jenis_ikan = '$data[jenis_ikan]'")[0];
        $stokTersedia = $getData['stok_maksimal'] - $getData['stok_masuk'];

        if ($stokTersedia > $data['stok']) {
          $success = true;
          $sql = "UPDATE penyetoran SET kapal = '$data[kapal]', alat = '$data[alat]', waktu = '$data[waktu]', jenis_ikan = '$data[jenis_ikan]', ikan = '$data[ikan]', stok = '$data[stok]' WHERE id = '$id'";
          $conn->query($sql);
        } else {
          $error = true;
        }
      }
      ?>


      <div class="row">
        <div class="col-sm-12">
          <div class="white-box">
            <a href="setoran.php" class="btn btn-secondary btn-sm text-white mb-3" value="ubah"><i class="fas fa-arrow-left"></i> Kembali</a>

            <form action="" method="post" enctype="multipart/form-data">
              <div class="mb-3">
                <label for="judul" class="form-label">Nama Kapal</label>
                <input type="text" class="form-control" id="judul" name="kapal" placeholder="" value="<?= $penyetoran['kapal'] ?>">
              </div>
              <div class="mb-3">
                <label for="judul" class="form-label">Alat Tangkap</label>
                <input type="text" class="form-control" id="judul" name="alat" placeholder="" value="<?= $penyetoran['alat'] ?>">
              </div>
              <div class="mb-3">
                <label for="judul" class="form-label">Waktu Penangkapan</label>
                <input type="date" class="form-control" id="judul" name="waktu" placeholder="" value="<?= $penyetoran['waktu'] ?>">
              </div>
              <div class="mb-3">
                <label for="judul" class="form-label">Ikan</label>
                <input type="text" class="form-control" id="judul" name="ikan" placeholder="" value="<?= $penyetoran['ikan'] ?>">
              </div>
              <div class="mb-3">
                <label for="judul" class="form-label">Jenis Ikan</label>
                <input type="text" class="form-control" id="judul" name="jenis_ikan" placeholder="" value="<?= $penyetoran['jenis_ikan'] ?>">
              </div>
              <div class="mb-3">
                <label for="judul" class="form-label">Stok</label>
                <input type="number" class="form-control" id="judul" name="stok" placeholder="" value="<?= $penyetoran['stok'] ?>">
              </div>

              <button type="submit" class="btn btn-info btn-sm text-white" name="ubah">Simpan</button>
            </form>


          </div>
        </div>
      </div>

      <!-- End Content -->
    </div>
  </div>

</div>

<?php
if ($success) {
  sAlert('Berhasil', 'Setoran Berhasil Diubah', 'success');
  direct("setoran.php", 1000);
}

if ($error) {
  sAlert('Gagal', 'Stok Setoran Melebihi Stok Maksimal', 'error');
}
?>

<?php require 'comp/footer.php'; ?>