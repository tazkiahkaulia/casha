<?php
require 'comp/header.php';

if (isset($_GET['id'])) {
  $id = clear($_GET['id']);
  $data = query_select('berita', "id='$id'");

  if ($data) {
    $imgName = $data[0]['img'];
    unlink('../assets/img/' . $imgName);
    query_delete('berita', "id = '$id'");
  }
}

sAlert('Berhasil', 'Kabar Berita Berhasil Dihapus', 'success');
direct('kabar_berita.php', 1000);
