<?php
$hal = "Tambah Kabar Berita";
$success = false;

?>
<?php require 'comp/header.php'; ?>

<div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full" data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">

  <?php require 'comp/navbar.php'; ?>
  <?php require 'comp/aside.php'; ?>

  <div class="page-wrapper">
    <?php require 'comp/sidebar-toggle.php'; ?>

    <div class="container-fluid">
      <!-- Content -->
      <h3 class="mb-4">Tambah Kabar Berita</h3>

      <?php
      if (isset($_POST['add'])) {
        $data = [
          'id' => '',
          "judul" => clear($_POST['judul']),
          "isi" => clear($_POST['isi']),
        ];

        if ($_FILES['gambar']['name']) {
          $fileName = newFilename() . getExt($_FILES['gambar']['name']);
          $data['img'] = $fileName;
          saveFile($_FILES, '../assets/img/' . $fileName);
        } else {
          $data['img'] = '';
        }

        $success = true;
        query_insert('berita', $data);
      }
      ?>


      <div class="row">
        <div class="col-sm-12">
          <div class="white-box">
            <a href="kabar_berita.php" class="btn btn-secondary btn-sm text-white mb-3" value="ubah"><i class="fas fa-arrow-left"></i> Kembali</a>

            <form action="" method="post" enctype="multipart/form-data">
              <div class="mb-3">
                <label for="judul" class="form-label">Judul Berita</label>
                <input type="text" class="form-control" id="judul" name="judul" placeholder="">
              </div>
              <div class="mb-3">
                <label for="isi" class="form-label">Isi Berita</label>
                <textarea class="form-control" id="isi" name="isi" rows="3"></textarea>
              </div>
              <div class="mb-3">
                <label for="isi" class="form-label">Gambar</label>
                <input class="form-control" type="file" name="gambar">
              </div>
              <button type="submit" class="btn btn-info btn-sm text-white" name="add">Simpan</button>
            </form>


          </div>
        </div>
      </div>

      <!-- End Content -->
    </div>
  </div>

</div>

<?php
if ($success) {
  sAlert('Berhasil', 'Kabar Berita Berhasil Ditambah', 'success');
  direct("kabar_berita.php", 1000);
}
?>

<?php require 'comp/footer.php'; ?>