<?php
$hal = "Data Nelayan";
$success = false;
?>
<?php require 'comp/header.php'; ?>

<div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full" data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">

  <?php require 'comp/navbar.php'; ?>
  <?php require 'comp/aside.php'; ?>

  <div class="page-wrapper">
    <?php require 'comp/sidebar-toggle.php'; ?>

    <div class="container-fluid">
      <!-- Content -->

      <h3 class="mb-4">Data Nelayan</h3>


      <div class="row">
        <div class="col-sm-12">
          <div class="white-box">
            <!-- <h3 class="box-title">Basic Table</h3>
            <p class="text-muted">Add class <code>.table</code></p> -->
            <a href="tambah_nelayan.php" class="btn btn-info btn-sm text-white">Tambah Nelayan</a>

            <div class="table-responsive">
              <table class="table text-nowrap">
                <thead>
                  <tr>
                    <th class="border-top-0">No.</th>
                    <th class="border-top-0">Nama</th>
                    <th class="border-top-0">Username</th>
                    <th class="border-top-0">Password</th>
                    <th class="border-top-0">Alamat</th>
                    <th class="border-top-0">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $user = query_select('users');
                  krsort($user);
                  ?>
                  <?php $i = 1 ?>
                  <?php if ($user) : ?>
                    <?php foreach ($user as $s) : ?>
                      <tr>
                        <td><?= $i ?></td>
                        <td style="white-space: pre-wrap;"><?= $s['nama'] ?></td>
                        <td style="white-space: pre-wrap;"><?= $s['username']  ?></td>
                        <td>
                          <?= $s['password'] ?>
                        </td>
                        <td>
                          <?= $s['alamat'] ?>
                        </td>
                        <td class="">
                          <a href="edit_nelayan.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-secondary text-white"><i class="fas fa-external-link-alt"></i></a>
                          <a href="hapus_nelayan.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-danger text-white"><i class="far fa-trash-alt"></i></a>
                        </td>
                      </tr>
                      <?php $i++ ?>
                    <?php endforeach; ?>
                  <?php else : ?>
                    <tr>
                      <td colspan="5" class="text-center text-danger">Belum Ada Nelayan Yang Ditambahkan</td>
                    </tr>
                  <?php endif; ?>

                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <!-- End Content -->
    </div>
  </div>

</div>


<?php require 'comp/footer.php'; ?>