<?php
require 'comp/header.php';

if (isset($_GET['id'])) {
  $id = clear($_GET['id']);

  query_delete('penyetoran', "id = '$id'");
}

sAlert('Berhasil', 'Setoran Berhasil Dihapus', 'success');
direct('setoran.php', 1000);
