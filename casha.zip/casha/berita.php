<?php $halaman = "Berita | CaSha" ?>
<?php require 'Comp/header.php'; ?>
<?php

require 'comp/koneksi.php';

$berita = query_select('berita');
krsort($berita);
?>



<style>
  .shadow-sm {
    box-shadow: 0px 3px 5px rgba(0, 0, 0, .15);
  }

  footer {
    text-align: center;
  }

  @media (max-width: 576px) {
    .card-title {
      font-size: 14px;
    }

    .card-text {
      font-size: 12px;
    }

    footer p {
      font-size: 10px;
    }
  }
</style>
<!-- Navbar -->
<?php require 'Comp/navbar.php'; ?>

<?php
function cetakIsi($kata)
{
  $data = '';
  for ($i = 0; $i < 100; $i++) {
    $data .= $kata[$i];
  }

  return $data;
}
?>
<!-- endnavbar -->

<!-- content -->
<section class="main mt-4 pt-4" id="berita " style="min-height: 88vh;">
  <div class="container pt-5">

    <div class="text-center pt-4">
      <h3 class="mb-5 pb-3">Semua Kabar Berita</h3>
    </div>

    <div class="row">

      <?php if ($berita) : ?>

        <?php $i = 0 ?>
        <?php foreach ($berita as $item) : ?>
          <div class="col-md-4 col-6 mb-4">
            <div class="card shadow border-0">
              <img class="card-img-top" src="assets/img/<?= $item['img'] ?>" alt="Card image cap">
              <div class="card-body">
                <h6 class="card-title fw-bold"><?= $item['judul'] ?></h6>
                <p class="text-secondary"><?= cetakIsi($item['isi']) ?>...</p>
                <a href="detail.php?id=<?= $item['id'] ?>">Selengkapnya</a>
              </div>
            </div>
          </div>
          <?php $i++ ?>
        <?php endforeach; ?>
      <?php endif; ?>

    </div>

  </div>

</section>
<!-- endContent -->

<footer class="pt-3 pb-4 bg-light mt-5">
  <p class="mb-0 text-secondary">Copyright 2022 | CaSha Web</p>
</footer>

<?php include 'Comp/footer.php'; ?>