<nav class="navbar navbar-expand-lg navbar-dark shadow bg-info fixed-top p-3">
  <div class="container">
    <!-- <a class="navbar-brand" href="#">SEPATU WARRIOR</a> -->
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav mx-auto my-auto">
        <!-- <a class="nav-item nav-link" href="index.php">Beranda</a> -->
        <a class="nav-item nav-link" href="berita.php">Kabar Berita</a>
        <a href="index.php" class="text-white ms-3 me-3" style="transform: translateY(3px); text-decoration: none">
          <h4 class="fw-bolder " style="text-transform: uppercase; ">CaSha</h4>
        </a>
        <a class="nav-item nav-link" href="penyetoran.php">Penyetoran</a>
        <!-- <a class="nav-item nav-link" href="produk.php">Produk</a> -->
      </div>
    </div>
  </div>
</nav>
<script>
  let navLink = document.querySelectorAll('.nav-link');
  navLink.forEach(e => {
    if (e.innerHTML == '<?= $halaman ?>') {
      e.classList.add('active');
    }
  });
</script>