<style>
  .jumbotron {
    height: 600px;
    background: url('assets/img/hero.jpg');
    background-size: cover;
    background-position: 0px 0px;
  }

  .jumbotron h2,
  .jumbotron h5 {
    text-shadow: 0px 3px 5px rgba(0, 0, 0, 0.35);
  }
</style>
<div class="jumbotron border mt-4">
  <div class="container pt-5 text-center" data-aos="zoom-in" data-aos-duration="1000">
    <h2 class="display-4 text-white mb-3 mt-4 pt-5">Selamat Datang Kembali, User</h2>
    <p class="text-white mb-4" style="width: 400px; margin: auto;"></p>
    <a href="#produk" class="btn btn-outline-info shadow text-info">Kabar Berita</a>
  </div>
</div>