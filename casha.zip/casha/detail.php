<?php
$halaman = "Detail Produk";
?>
<?php require 'comp/header.php'; ?>

<?php
$alert;
require 'comp/koneksi.php';

$id = clear($_GET['id']);

$res = query_select('berita', "id = '$id'");
if (!$res) {
  direct('index.php');
  die;
}

$berita = $res[0];
?>

<?php require 'comp/navbar.php'; ?>

<section class="main mt-3 pt-5">

  <div class="container pt-4">
    <div class="card shadow-sm border-0 mt-4">
      <div class="card-body">
        <h2 class="mb-4 mt-3"><?= $berita['judul'] ?></h2>

        <div class="text-center">
          <img src="assets/img/<?= $berita['img'] ?>" class="img-fluid rounded" alt="">
        </div>

        <p class="mt-3" style="text-align: justify; font-size: 1.2rem">
          <?= $berita['isi'] ?>
        </p>

      </div>
    </div>

  </div>
</section>

<?php include 'Comp/footer.php'; ?>