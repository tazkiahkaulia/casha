<?php $halaman = "Data Penyetoran | CaSha" ?>
<?php require 'Comp/header.php'; ?>
<?php

require 'comp/koneksi.php';

?>

<style>
  .shadow-sm {
    box-shadow: 0px 3px 5px rgba(0, 0, 0, .15);
  }

  footer {
    text-align: center;
  }

  @media (max-width: 576px) {
    .card-title {
      font-size: 14px;
    }

    .card-text {
      font-size: 12px;
    }

    footer p {
      font-size: 10px;
    }
  }
</style>
<!-- Navbar -->
<?php require 'Comp/navbar.php'; ?>
<!-- endnavbar -->


<!-- content -->
<section class="main mt-4 pt-4" id="berita " style="min-height: 88vh;">
  <div class="container pt-4">

    <div class="text-center pt-4">
      <h3 class="mb-4 pb-3">Data Penyetoran</h3>
    </div>
    <?php
    $penyetoran = query_select('penyetoran');
    $stok = query_select('stok_penyetoran');
    krsort($penyetoran);

    foreach ($stok as $val) :
    ?>
      <h5><?= $val['jenis_ikan'] ?> : <?= $val['stok_masuk'] ?> kg <?= $val['stok_masuk'] * 100 / $val['stok_maksimal'] > 50 ? "<span class='badge bg-warning'>Maksimal " . $val['stok_maksimal'] . " kg</span>" : "" ?></h5>
    <?php endforeach; ?>
    <br>
    <table class="table">
      <thead>
        <tr>
          <th>No</th>
          <th>Nama Kapal</th>
          <th>Alat Tangap</th>
          <th>Waktu Tangkapan</th>
          <th>Ikan</th>
          <th>Jenis Ikan</th>
          <th>Jumlah Ikan (Kg)</th>
        </tr>
      </thead>
      <tbody>
        <?php $i = 1 ?>
        <?php foreach ($penyetoran as $item) : ?>
          <tr>
            <td>
              <?= $i ?>
            </td>
            <td><?= $item['kapal'] ?></td>
            <td><?= $item['alat'] ?></td>
            <td><?= $item['waktu'] ?></td>
            <td><?= $item['ikan'] ?></td>
            <td><?= $item['jenis_ikan'] ?></td>
            <td><?= $item['stok'] ?></td>

          </tr>
          <?php $i++ ?>
        <?php endforeach; ?>
      </tbody>
    </table>

  </div>

</section>
<!-- endContent -->

<footer class="pt-3 pb-4 bg-light mt-5">
  <p class="mb-0 text-secondary">Copyright 2022 | CaSha Web</p>
</footer>

<?php include 'Comp/footer.php'; ?>