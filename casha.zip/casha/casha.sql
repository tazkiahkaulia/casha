-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 23, 2022 at 10:29 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `casha`
--

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE `berita` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) DEFAULT NULL,
  `isi` text DEFAULT NULL,
  `img` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`id`, `judul`, `isi`, `img`) VALUES
(12, 'KKP Perbarui Data Estimasi Potensi Ikan, Totalnya 12,01 Juta Ton per Tahun', 'Kementerian Kelautan dan Perikanan (KKP) memperbarui data estimasi potensi sumber daya ikan (SDI) yang ada di 11 Wilayah Pengelolaan Perikanan Negara Republik Indonesia (WPPNRI) menyusul terbitnya Keputusan Menteri Kelautan dan Perikanan (Kepmen KP) Nomor 19 Tahun 2022. Penetapan estimasi potensi ikan saat ini diakui lebih baik karena menggunakan metodologi penghitungan yang semakin baik pula untuk mendukung implementasi program pengelolaan perikanan berkelanjutan, salah satunya kebijakan penangkapan terukur.', '1670591732423.jpeg'),
(14, 'Pelabuhan Perikanan Penggerak Utama Perekonomian Masyarakat Nelayan', 'Keberadaan pelabuhan perikanan memiliki fungsi penting bagi masyarakat nelayan dalam menunjang kegiatan penangkapan ikan, sekaligus menjadi pusat perekonomian masyarakat.\r\nPelabuhan Perikanan Nusantara (PPN) Karangantu senantiasa melakukan evaluasi, inovasi dan perbaikan guna meningkatkan kinerja dalam memberikan pelayanan kepada masyarakat yang beraktivitas di pelabuhan perikanan.', '1670591841181.jpg'),
(15, 'Siasat KKP Atasi Dampak Perubahan Iklim di Sektor Kelautan dan Perikanan', 'Peningkatan suhu menyebabkan terjadinya perubahan iklim di berbagai belahan bumi. Seiring dengan menghangatnya suhu dan meningkatnya keasaman perairan laut, stok ikan diprediksi akan bergerak menuju habitat yang lebih sesuai. Indonesia, sebagai negara tropis, diperkirakan akan menghadapi dampak yang lebih parah dibandingkan dengan kawasan lainnya di dunia, terlebih di sektor perikanan.\r\nSebagai negara penyumbang hampir 7% dari produksi ikan global, perubahan iklim dapat mempengaruhi ketahanan pangan, keselamatan nelayan, konservasi dan keanekaragaman hayati, serta perekonomian yang dihasilkan oleh sektor kelautan dan perikanan. Jika kegiatan ekonomi berlanjut seperti biasa, dengan tingkat tekanan penangkapan ikan dan pemanasan laut saat ini, maka hasil perikanan kemungkinan akan menurun dan 80% stok dunia jatuh ke status penangkapan berlebih pada pertengahan dekade berikutnya.', '1670591925484.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `penyetoran`
--

CREATE TABLE `penyetoran` (
  `id` int(11) NOT NULL,
  `kapal` varchar(100) NOT NULL DEFAULT '0',
  `alat` varchar(100) NOT NULL DEFAULT '0',
  `waktu` varchar(100) NOT NULL DEFAULT '0',
  `jenis_ikan` varchar(100) NOT NULL DEFAULT '0',
  `ikan` varchar(100) NOT NULL DEFAULT '0',
  `stok` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Triggers `penyetoran`
--
DELIMITER $$
CREATE TRIGGER `penyetoran_hapus_data` BEFORE DELETE ON `penyetoran` FOR EACH ROW BEGIN
	UPDATE stok_penyetoran SET stok_masuk = stok_masuk - OLD.stok
	WHERE jenis_ikan = OLD.jenis_ikan;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `penyetoran_update` BEFORE UPDATE ON `penyetoran` FOR EACH ROW BEGIN
	UPDATE stok_penyetoran
	SET stok_masuk = stok_masuk - OLD.stok + NEW.stok
	WHERE jenis_ikan = OLD.jenis_ikan;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `stok_penyetoran`
--

CREATE TABLE `stok_penyetoran` (
  `id` int(11) NOT NULL,
  `jenis_ikan` varchar(200) DEFAULT NULL,
  `stok_maksimal` int(11) DEFAULT 0,
  `stok_masuk` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stok_penyetoran`
--

INSERT INTO `stok_penyetoran` (`id`, `jenis_ikan`, `stok_maksimal`, `stok_masuk`) VALUES
(1, 'Pelagis', 100, 0),
(2, 'Demersal', 70, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `role` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `nama`, `alamat`, `role`) VALUES
(1, 'andi_firmansyah', '123', 'Andi Firmansyah', '                  Jl Panglima Batur      ', 2),
(3, 'Kapal Alan', 'Jaring', '2022-12-09', 'Tongkol', 0),
(4, 'admin', 'admin123', 'Administrator', NULL, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `penyetoran`
--
ALTER TABLE `penyetoran`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stok_penyetoran`
--
ALTER TABLE `stok_penyetoran`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `berita`
--
ALTER TABLE `berita`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `penyetoran`
--
ALTER TABLE `penyetoran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `stok_penyetoran`
--
ALTER TABLE `stok_penyetoran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
